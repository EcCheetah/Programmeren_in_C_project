#ifndef MAIN_H
#define MAIN_H

// All Globals We Use //
extern SDL_Window *window;
extern SDL_Renderer *renderer;

extern struct _posblock_ posblocks[700];
extern struct _enemy_ enemies[ENEMY_COUNTER];
extern struct _tower_ towers[TOWER_COUNTER];

extern posblock hoverBlock;

extern int routeCounter;
extern int towerHealth;
extern int goAhead;

extern char *text_orc[8];

#endif