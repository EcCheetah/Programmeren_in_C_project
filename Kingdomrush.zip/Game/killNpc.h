#ifndef KILLNPC_H
#define KILLNPC_H

void buildTower();
void drawTower();
void checkDamage(int enemyId);

#endif