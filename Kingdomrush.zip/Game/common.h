#ifndef COMMON_H
#define COMMON_H

#include <stdio.h> 
#include <stdlib.h>
#include <SDL2/SDL.h> 
#include <SDL2/SDL_image.h> // for IMG_Init and IMG_LoadTexture 
#include <math.h> // for collision

#define SCREEN_WIDTH	1600
#define SCREEN_HEIGHT	1000	
 
#define BOX_ON_X		32
#define BOX_ON_Y		20

#define SPEED_ENEMY		5 // 1

#define ENEMY_COUNTER	4
#define TOWER_COUNTER	11

// A mouse structure holds mousepointer coords & a pointer texture:
typedef struct _mouse_ {
	int x;
 	int y;
  	SDL_Texture *txtr_reticle;
} mouse;

typedef enum _posblockstate_ {
	ROAD = 0,
	BUILDING_FREE = 1,
	BUILDING_BUILD = 2,
	GRASS = 3,
} posblockstate;
typedef struct _posblock_ {
	int id_block;
	int x;
	int y;
	posblockstate stateblock;
	SDL_Texture *txtr_block;
} posblock;

typedef enum _enemyType_ {
	ORC
} enemyType;
typedef struct _enemy_ {
	int id;
	int x;
	int y;
	enemyType type;
	int health;
	int route;	   // One Of 4 Routes
	int direction; // x- / x+ / y- / y+

	int routeCounter;
	int textureCounter;

	int keypoints[50];
	int direct[50];
} enemy;

typedef enum _towerType_ {
	ARCHERTOWER,
	WIZARDTOWER,
	BOMBTOWER
} towerType;
typedef struct _tower_ {
	int id_tower;
	int id_block;
	int x;
	int y;
	towerType type;
	int radius;
	int damage;
} tower;

#endif