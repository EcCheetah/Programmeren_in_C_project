#ifndef BASICS_H
#define BASICS_H

void blit(SDL_Texture *txtr, int x, int y, int center);
void initSDL(int argc, char *argv[]);
SDL_Texture *load_texture(char *filename);

#endif