#ifndef MAKE_H
#define MAKE_H

void makeCastle(int x, int y, int width, int height);
void makeGrid();
void makeRoads(); // contains a lot of makeroad() 
void makeTowers(); // contains a lot of makeTower()
void makeTower(int x, int y, int towerCounter);
void makeEnemies();

#endif