#ifndef ENEMY_H
#define ENEMY_H

void updateNpc();
void featuresNpc();

#endif