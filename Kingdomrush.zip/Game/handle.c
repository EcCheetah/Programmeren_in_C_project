#include "common.h"
#include "main.h"
#include "handle.h"
#include "killNpc.h"

void process_input(mouse *tha_mouse) {	
  	SDL_Event event;
	
  	while (SDL_PollEvent(&event))	{		
    	switch (event.type) {
      		case SDL_QUIT:	
        		proper_shutdown();
        		exit(0);
			break;
      		case SDL_KEYDOWN:	
				if (event.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
					proper_shutdown();					
					exit(0);
				}
				break;
			case SDL_MOUSEBUTTONDOWN:
				if (goAhead == 0) {
					goAhead = 1;
				}
				else if (goAhead == 1) {
					buildTower();
				}
				break;
      		default:
				break;		
    	}
  	}

  	// NEW -- Read the mouse position here:
  	SDL_GetMouseState(&tha_mouse->x, &tha_mouse->y);
}

void proper_shutdown(void) {
  	SDL_DestroyRenderer(renderer);
  	SDL_DestroyWindow(window);
  	SDL_Quit();
}

void targetPosBlock(mouse *tha_mouse) {
	// get all the blocks out of array
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			// calculate index
			int index = ((BOX_ON_X * a) + b);

			// get the current posblock out with the index
			posblock currentPosblock = posblocks[index];

			// see if the mouse is in a posblock
			int blockX = currentPosblock.x;
			int blockY = currentPosblock.y;
			int mouseX = tha_mouse->x;
			int mouseY = tha_mouse->y;
			if ((blockX < mouseX && blockX + 50 > mouseX) && (blockY < mouseY && blockY + 50 > mouseY)) {
				// post the current posblock to the hoverblock
				hoverBlock = currentPosblock;
			}
		}
	}
}

