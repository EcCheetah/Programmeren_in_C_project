#include "common.h"
#include "main.h"
#include "make.h"
#include "basics.h"

void makeGrid() {
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			int index = ((BOX_ON_X * a) + b);

			posblock newblock; //Creates a new positionblock

			//Set a view values
			newblock.id_block	= index;
			newblock.x			= (b * 50);
			newblock.y			= (a * 50);
			newblock.stateblock	= GRASS;
			newblock.txtr_block	= load_texture("gfx/reticle.png");

			posblocks[index] = newblock;
		}
	}
}

void makeRoads() {
	// all pos for roads
	int xPos[50] = {300, 500, 550, 850, 850, 1000, 1000, 1450, 150, 150, 350, 150, 150, 150, 900, 950, 1100, 1100, 600, 650};
	int yPos[50] = {150, 200, 250, 200, 150, 200, 300, 300, 300, 450, 500, 700, 750, 850, 400, 550, 300, 850, 400, 400};
	int wPos[50] = {250, 50, 300, 50, 200, 50, 450, 50, 50, 250, 50, 250, 50, 800, 50, 500, 50, 250, 50, 250};
	int hPos[50] = {50, 100, 50, 100, 50, 100, 50, 450, 150, 50, 200, 50, 100, 50, 450, 50, 550, 50, 450, 50};

	for (int q = 0; q < 50; q++) {
		SDL_Rect pieceOfRoad;
		pieceOfRoad.x = xPos[q];
		pieceOfRoad.y = yPos[q];
		pieceOfRoad.w = wPos[q];
		pieceOfRoad.h = hPos[q];

		SDL_SetRenderDrawColor(renderer, 255, 187, 51, 255);
		SDL_RenderFillRect(renderer, &pieceOfRoad);
	}
}

void makeCastle(int x, int y, int width, int height) {
  	SDL_Rect pieceOfCastle;
  	pieceOfCastle.x = x;
  	pieceOfCastle.y = y;
  	pieceOfCastle.w = width;
  	pieceOfCastle.h = height;

	SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255);
	SDL_RenderFillRect(renderer, &pieceOfCastle);
}

void makeTowers() {
	// an array with all x spots and one for y spots
	int xSpots[50] = {600, 1100, 1550, 250, 1000, 1200, 700, 800, 1350, 450, 50};
	int ySpots[50] = {150, 200, 300, 600, 650, 750, 550, 700, 450, 500, 800};

	for (int q = 0; q < TOWER_COUNTER; q++) {
		// make towers
		makeTower(xSpots[q], ySpots[q], q);
	}
}

void makeTower(int x, int y, int towerCounter) {
	// make a new tower
	tower newTower;

	// set x and y to the tower
	newTower.id_tower = towerCounter;
	newTower.x = x;
	newTower.y = y;

	// post the tower
	towers[towerCounter] = newTower;

	// get all the blocks out of array
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			// calculate index
			int index = ((BOX_ON_X * a) + b);

			// get the current posblock out with the index
			posblock currentPosblock = posblocks[index];

			// check if the current posblock its x is equal to the given x
			if((currentPosblock.x == x) && (currentPosblock.y == y)) {
				// set the current posblock
				currentPosblock.stateblock = BUILDING_FREE;

				// post the current posblock
				posblocks[index] = currentPosblock;
			}
		}
	}
}

void makeEnemies() {
	for (int q = 0; q < ENEMY_COUNTER; q++) {
		if (enemies[q].health <= 0) {
			// Make orc
			enemy newEnemy = {q, 0, 0, ORC, 100, 0, 0, 0, 0, {0}, {0}};

			int routeCheck = q % 4;

			// route 1
			if (routeCheck == 0) {
				newEnemy.x = 300;
				newEnemy.y = 150;

				// either route 0 or 1
				newEnemy.route = q;

				newEnemy.direction = 1;
		
				// set the route
				int keypointsRoute[50] = {
					525/* x */, 250 /* y */, 875 /* x */, 150 /* y */,
					1025, 300, 1475, 750
				};
				int directRoute[50] = { // 0 = LEFT // 1 = RIGHT // 2 = UP // 3 = DOWN // 4 = FINISH
					3, 1, 2, 1, 3, 1, 3, 4
				};
				for (int a = 0; a < 50; a++) {
					newEnemy.keypoints[a] = keypointsRoute[a];
					newEnemy.direct[a] = directRoute[a];
				}					
			} 
			
			// route 2
			else if (routeCheck == 1) {
				newEnemy.x = 175;
				newEnemy.y = 300;

				// either route 2 or 3
				newEnemy.route = q;

				newEnemy.direction = 3;

				// set the route
				int keypointsRoute[50] = {
					450, 375, 700, 175, 850, 625, 400, 925, 550, 1125, 850, 1350
				};
				int directRoute[50] = { // 0 = LEFT // 1 = RIGHT // 2 = UP // 3 = DOWN // 4 = FINISH
					1, 3, 0, 3, 1, 2, 1, 3, 1, 3, 1, 4
				};
				for (int a = 0; a < 50; a++) {
					newEnemy.keypoints[a] = keypointsRoute[a];
					newEnemy.direct[a] = directRoute[a];
				}					
			}

			// route 3
			else if (routeCheck == 2) {
				newEnemy.x = 175;
				newEnemy.y = 300;

				// either route 2 or 3
				newEnemy.route = q;

				newEnemy.direction = 3;

				// set the route
				int keypointsRoute[50] = {
					450, 375, 700, 175, 850, 925, 550, 1475, 750
				};
				int directRoute[50] = { // 0 = LEFT // 1 = RIGHT // 2 = UP // 3 = DOWN // 4 = FINISH
					1, 3, 0, 3, 1, 2, 1, 3, 4
				};
				for (int a = 0; a < 50; a++) {
					newEnemy.keypoints[a] = keypointsRoute[a];
					newEnemy.direct[a] = directRoute[a];
				}					
			}

			// route 4
			else if (routeCheck == 3) {
				newEnemy.x = 300;
				newEnemy.y = 150;

				// either route 0 or 1
				newEnemy.route = q;

				newEnemy.direction = 1;
				
				// set the route
				int keypointsRoute[50] = {
					525/* x */, 250 /* y */, 875 /* x */, 150 /* y */,
					1025, 300, 1125, 850, 1350
				};
				int directRoute[50] = { // 0 = LEFT // 1 = RIGHT // 2 = UP // 3 = DOWN // 4 = FINISH
					3, 1, 2, 1, 3, 1, 3, 1, 4
				};
				for (int a = 0; a < 50; a++) {
					newEnemy.keypoints[a] = keypointsRoute[a];
					newEnemy.direct[a] = directRoute[a];
				}					
			} 
			
			enemies[q] = newEnemy;
		}
	}
}
