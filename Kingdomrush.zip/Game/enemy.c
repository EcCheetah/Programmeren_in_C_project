#include "common.h"
#include "main.h"
#include "enemy.h"
#include "basics.h"
#include "killNpc.h"

void updateNpc() {
		for (int q = 0; q < ENEMY_COUNTER; q++) {
			// Get enemy
			enemy currentEnemy = enemies[q];

			// update x and y pos
			switch (currentEnemy.direction) {
			case 0: // x-
				currentEnemy.x = currentEnemy.x - SPEED_ENEMY;
				break;
			case 1: // x+
				currentEnemy.x = currentEnemy.x + SPEED_ENEMY;
				break;
			case 2: // y-
				currentEnemy.y = currentEnemy.y - SPEED_ENEMY;
				break;
			case 3: // y+
				currentEnemy.y = currentEnemy.y + SPEED_ENEMY;
				break;
			default:
				break;
			}

			// Check if enemy is at loation x
			if (currentEnemy.direction == 0 || currentEnemy.direction == 1) {
				if (currentEnemy.x == currentEnemy.keypoints[currentEnemy.routeCounter]) {
					currentEnemy.direction = currentEnemy.direct[currentEnemy.routeCounter];
					
					currentEnemy.routeCounter = currentEnemy.routeCounter + 1;
				}

				// if enemy reaches the end kill the game
				if (currentEnemy.direction == 4) { 
					towerHealth = towerHealth - 1; 
					currentEnemy.health = 0;
				}
			}
			// Check if enemy is at loation y
			else if (currentEnemy.direction == 2 || currentEnemy.direction == 3) {
				if (currentEnemy.y == currentEnemy.keypoints[currentEnemy.routeCounter]) {
					currentEnemy.direction = currentEnemy.direct[currentEnemy.routeCounter];
					
					currentEnemy.routeCounter = currentEnemy.routeCounter + 1;
				}

				// if enemy reaches the end kill the game
				if (currentEnemy.direction == 4) { 
					towerHealth = towerHealth - 1; 
					currentEnemy.health = 0;
				}
			}

			// Post enemy
			enemies[q] = currentEnemy;
		}

}

void featuresNpc() {
		for (int q = 0; q < ENEMY_COUNTER; q++) {
			// create a texture
			SDL_Texture *text_mob;

			// get the current enemy
			enemy theEnemy = enemies[q];

			// check the type of enemy
			if (theEnemy.type == ORC) {
				// reset texture counter
				if (theEnemy.textureCounter == 8) {
					theEnemy.textureCounter = 0;
				}

				// get texture
				text_mob = load_texture(text_orc[theEnemy.textureCounter]);

				// add one to texture counter
				theEnemy.textureCounter = theEnemy.textureCounter + 1;

				// put it on the screen
				blit(text_mob, theEnemy.x, theEnemy.y, 1);
			}
			
			// post the enemy
			enemies[q] = theEnemy;

			// check if enemy is within range of towers
			checkDamage(theEnemy.id);

			// make a healthbar
			SDL_Rect redBar;

			redBar.x = theEnemy.x;
			redBar.y = theEnemy.y - 45;
			redBar.h = 2;
			redBar.w = 25;

			SDL_Rect greenbar = redBar;

			greenbar.w = theEnemy.health / 4;

			SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
			SDL_RenderFillRect(renderer, &redBar);

			SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
			SDL_RenderFillRect(renderer, &greenbar);
		}
		
}
