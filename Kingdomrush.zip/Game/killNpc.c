#include "common.h"
#include "main.h"
#include "killNpc.h"
#include "basics.h"

void buildTower() {
	// make a new posblock and index
	posblock thePosblock;

	// loop over all posblocks (and assign the correct posblock)
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			// calculate index
			int index = ((BOX_ON_X * a) + b);

			// get the current posblock out with the index
			posblock currentPosblock = posblocks[index];

			// check if currentposblock is equal to hoverblock
			if (currentPosblock.x == hoverBlock.x && currentPosblock.y == hoverBlock.y) {
				if (currentPosblock.stateblock == BUILDING_FREE) {
					// overwrite the posblock with current posblock
					thePosblock = currentPosblock;

					thePosblock.stateblock = BUILDING_BUILD;
					posblocks[index] = thePosblock;
				}
			}
		}
	}

	// loop over all towers
	for (int q = 0; q < TOWER_COUNTER; q++) {
		tower currentTower = towers[q]; // at this point tower has id, x and y

		if (currentTower.x == thePosblock.x && currentTower.y == thePosblock.y) {
			// write current tower to the tower
			tower theTower = currentTower;

			// for now assign hardcoded type
			theTower.id_block = thePosblock.id_block;
			theTower.type     = ARCHERTOWER;

			// assign damage and radius according to type
			if (theTower.type == ARCHERTOWER) {
				theTower.damage	  = 1;
				theTower.radius   = 200;
			}

			// post the new tower
			towers[q] = theTower;
		}
	} 
}

void drawTower() {
	// loop over all posblocks (and assign the correct posblock)
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			// calculate index
			int index = ((BOX_ON_X * a) + b);

			// get the current posblock out with the index
			posblock currentPosblock = posblocks[index];

			// if current posblock its state FREE or BUILD make the square
			if (currentPosblock.stateblock == BUILDING_FREE || currentPosblock.stateblock == BUILDING_BUILD) {
				// init the square
				SDL_Rect towerSpot;

				// set its position and size
				towerSpot.w = 50;
				towerSpot.h = 50;
				towerSpot.x = currentPosblock.x;
				towerSpot.y = currentPosblock.y;

				// set color and print
				SDL_SetRenderDrawColor(renderer, 150, 150, 150, 255);
				SDL_RenderFillRect(renderer, &towerSpot);
			}

			// only if the current posblock has a building
			if (currentPosblock.stateblock == BUILDING_BUILD) {
				for (int q = 0; q < TOWER_COUNTER; q++) {
					// get the tower
					tower currentTower = towers[q];
					
					// check if tower id_block is equal of id_block of current posblock
					if (currentTower.id_block == currentPosblock.id_block) {
						SDL_Texture *textureTower;

						if (currentTower.type == ARCHERTOWER) {
							textureTower = load_texture("gfx/tow_text/archertower.png");
						}

						// show me the image
						blit(textureTower, currentPosblock.x + 25, currentPosblock.y + 15, 1);
					}
				}
			}
		}
	}
}

void checkDamage(int enemyId) {
	// loop over all posblocks (and assign the correct posblock)
	for(int a = 0; a < BOX_ON_Y + 1; a++) { // y
		for(int b = 0; b < BOX_ON_X + 1; b++) { // x
			// calculate index
			int index = ((BOX_ON_X * a) + b);

			// get the current posblock out with the index
			posblock currentPosblock = posblocks[index];

			// only if the current posblock has a building
			if (currentPosblock.stateblock == BUILDING_BUILD) {
				// loop over all towers
				for (int q = 0; q < TOWER_COUNTER; q++) {
					tower currentTower = towers[q];
				
					if (currentTower.id_block == currentPosblock.id_block) {
						// loop over all enemies
						for (int q = 0; q < ENEMY_COUNTER; q++) {
							enemy currentEnemy = enemies[q];

							if (currentEnemy.id == enemyId) {
								// calculate distance
								double distX = pow((currentEnemy.x - currentTower.x), 2);
								double distY = pow((currentEnemy.y - currentTower.y), 2);
								double pyth	 = sqrt(distX + distY);

								// do radius + 1 for tower range
								double radius = currentTower.radius + 1;

								// see if they overlap
								if (radius > pyth) {
									currentEnemy.health = currentEnemy.health - currentTower.damage;

									enemies[q] = currentEnemy;
								}
							}
						}					
					}
				}
			}
		}
	}
}
