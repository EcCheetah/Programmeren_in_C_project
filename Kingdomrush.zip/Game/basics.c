#include "common.h"
#include "main.h"
#include "basics.h"

void blit(SDL_Texture *txtr, int x, int y, int center) {
  	SDL_Rect dest;
  	dest.x = x;
  	dest.y = y;

  	SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);

  	// If center != 0, render texture with its center on (x,y), NOT
  	// with its top-left corner...
  	if (center) {
    		dest.x -= dest.w / 2;
    		dest.y -= dest.h / 2;
  	}

  	SDL_RenderCopy(renderer, txtr, NULL, &dest);
}

void initSDL(int argc, char *argv[]) {
 	(void)argc;
 	(void)argv;
	
  	unsigned int window_flags = 0;
	unsigned int renderer_flags = SDL_RENDERER_ACCELERATED;

  	if (SDL_Init(SDL_INIT_VIDEO) < 0) exit(1);
  	window = SDL_CreateWindow("Kingdom Rush: The battle of dwarfkingdom Moria", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, window_flags);
  	if (window == NULL) exit(1);	
  	renderer = SDL_CreateRenderer(window, -1, renderer_flags);
  	if (renderer == NULL) exit(1);	

   	IMG_Init(IMG_INIT_PNG);
}

SDL_Texture *load_texture(char *filename) {
  	SDL_Texture *txtr;
  	txtr = IMG_LoadTexture(renderer, filename);
  	return txtr;
}

