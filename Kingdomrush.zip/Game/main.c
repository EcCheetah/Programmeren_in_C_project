// Include all the files
#include "common.h"
#include "main.h"
#include "handle.h"
#include "basics.h"
#include "make.h"
#include "killNpc.h"
#include "enemy.h"

// These are all the used globals
SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;

struct _posblock_ posblocks[700];
struct _enemy_ enemies[ENEMY_COUNTER];
struct _tower_ towers[TOWER_COUNTER];

posblock hoverBlock;

int routeCounter = 0;
int towerHealth	= 5;
int goAhead = 0;

char *text_orc[8] = {
	"gfx/mob_text/orc/run001.png", "gfx/mob_text/orc/run002.png",
	"gfx/mob_text/orc/run003.png", "gfx/mob_text/orc/run004.png",
	"gfx/mob_text/orc/run005.png", "gfx/mob_text/orc/run006.png",
	"gfx/mob_text/orc/run007.png", "gfx/mob_text/orc/run008.png"
};

int main(int argc, char *argv[]) {
	// Step 1: BUILD SDL
	initSDL(argc, argv);

	// Step 2: BUILD GAME SETUP
	// Make mouse
  	mouse mousepointer;

	// Make the grid 
	makeGrid();
	makeTowers();

	// Step 3: Play the game
	while (1) {
		// Always make a clear first
		SDL_SetRenderDrawColor(renderer, 179, 119, 0, 255);
    	SDL_RenderClear(renderer);

		// Check all the counters 
		if (towerHealth <= 0) {
			proper_shutdown();
			exit(0); 
		}

		for (int q = 0; q < towerHealth; q++) {
			int x = q * 30;
			blit(load_texture("gfx/lives.png"), 1400 + x, 30, 1);
		}

		// Make the 2 castles 
		makeCastle(50, 50, 250, 250);
		makeCastle(1350, 750, 200, 200);

		// Make the roads
		makeRoads();

		// Spawn the towers
		drawTower();

		// Alows input from player
		process_input(&mousepointer);

		// Ensures hover action
		targetPosBlock(&mousepointer);

		// Make a basic enemy (also after it dies)
		makeEnemies();
		
		// Npc movement
		updateNpc();

		// Kill, hurt and dies (enemy)
		featuresNpc();

		// Wait a sec
		SDL_RenderPresent(renderer);
		SDL_Delay(16);
  	}

  	return 0;
}
