#ifndef HANDLE_H
#define HANDLE_H

void process_input(mouse *tha_mouse);
void proper_shutdown(void);
void targetPosBlock(mouse *tha_mouse);

#endif